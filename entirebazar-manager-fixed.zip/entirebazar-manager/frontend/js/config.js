// Firebase Web App config for project: entirebazar-360
// Replace FIREBASE_WEB_APP_ID with the appId shown in Firebase Console > Project settings > Your apps > Web app.
// Replace API_BASE_URL with the public HTTPS URL of the deployed Node.js backend (no trailing slash).
// Do not put Telegram bot tokens or service-account keys in this file.
export const firebaseConfig = {
  apiKey: 'AIzaSyCanErjh8BfPS6Wrz6QWcYrwec1ajAPFEg',
  authDomain: 'entirebazar-360.firebaseapp.com',
  projectId: 'entirebazar-360',
  appId: 'FIREBASE_WEB_APP_ID',
};

export const API_BASE_URL = 'https://REPLACE_WITH_YOUR_BACKEND_URL';
