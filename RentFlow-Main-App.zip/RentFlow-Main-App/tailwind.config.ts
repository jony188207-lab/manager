import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        forest: {
          50: "#effaf3",
          100: "#d8f3e2",
          200: "#b3e6c6",
          500: "#2e9e62",
          600: "#1f7d4b",
          700: "#17633c",
          800: "#124d31",
          900: "#0c3a25",
          950: "#072616",
        },
        brand: {
          50: "#eef6ff",
          100: "#d9eaff",
          500: "#2f6fed",
          600: "#2158cc",
          700: "#1b46a3",
          900: "#10244f",
        },
      },
    },
  },
  plugins: [],
};

export default config;
