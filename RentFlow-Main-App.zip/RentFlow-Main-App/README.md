# RentFlow — MAIN APP  (ZIP 1 of 2 · deploy this FIRST)

The public website and everything applicants use. The separate **RentFlow-Admin-Panel** project uses the same Firebase project.

> **Honest status:** this code has **not** been installed, type-checked, built or test-run. The environment that produced it could not reach the npm registry. Only a syntax-only TypeScript check was run (0 syntax errors). On your machine run
> `npm install && npm run typecheck && npm test && npm run build` and fix whatever is reported **before** going live. Nothing here is "production-ready" until that passes and you have tested the flows with your own Firebase project.
> Legal pages and consent text are **templates, not legal advice**; have an attorney review them before taking real applications.

## What is in this ZIP
| Area | Files |
|---|---|
| Website | Home, How it works, Pricing, Contact, Privacy, Terms, Applicant Rights (`src/app/*`) |
| Applicant registration / login | `/apply` (Firebase Auth email+password, verified email required) |
| Rental application form + reference number `RF-XXXXXXXX` | `/apply`, `src/app/api/applicant/applications` |
| Payment method selection + proof submission (transaction reference + screenshot) | `/apply`, `src/app/api/public/checkout`, `src/app/api/applicant/payments`, `src/app/api/public/payment-methods/[id]/qr` |
| Application + payment status | `/status`, `src/app/api/status`, "Your applications" in `/apply` |
| Contact form | `src/app/api/contact` |
| Provider webhook receiver (HMAC-verified) | `src/app/api/webhooks/payments` |
| Shared backend library | `src/lib/*` (Firebase Admin SDK, pricing, validation, audit, rate limit, upload checks) |
| Database + storage rules, indexes | `firestore.rules`, `firestore.indexes.json`, `storage.rules` |
| Tests | `tests/` (applicant flow, payment-method validation, webhook, QR route, shared lib) |

**Not in this ZIP:** the admin UI and `/api/admin/*` (see the Admin Panel ZIP). Without the Admin Panel, nobody can verify payments, so applicants stay in "Pending Verification".

## Setup
1. Node.js 20+.
2. **Firebase** (console.firebase.google.com): create a project → Authentication → enable **Email/Password** → create Firestore (production mode) → create a Storage bucket (private) → Project settings: add a **Web app** (copy its config) and generate a **service-account key** (keep that JSON private; copy its three values into env vars only).
3. `npm install`, `cp .env.example .env.local`, fill the values (list below). `openssl rand -base64 32` for `DATA_ENCRYPTION_KEY`.
4. `npm run dev` → http://localhost:3000
5. **Deploy rules (once per Firebase project — from this ZIP):**
   `npm i -g firebase-tools && firebase login && firebase use <project-id> && firebase deploy --only firestore:rules,firestore:indexes,storage`
   (needs a `firebase.json` pointing at the three files; `firebase init` creates it.) Then Firestore → TTL policies → collection `rateLimits`, field `expiresAt`.
6. Vercel: import the repo as its own project, add every variable under Settings → Environment Variables (mark secrets Sensitive), add the domain under Firebase Auth → Authorized domains.

## Configuration list (this app)
| Variable | Secret? | Notes |
|---|---|---|
| `NEXT_PUBLIC_FIREBASE_API_KEY`, `_AUTH_DOMAIN`, `_PROJECT_ID`, `_APP_ID` | no (public by design) | Web-app config |
| `FIREBASE_ADMIN_PROJECT_ID`, `FIREBASE_ADMIN_CLIENT_EMAIL`, `FIREBASE_ADMIN_PRIVATE_KEY` | **yes** | Service account; key with literal `\n` inside double quotes |
| `FIREBASE_STORAGE_BUCKET` | no | Private bucket |
| `DATA_ENCRYPTION_KEY` | **yes** | Encrypts SSN; **must equal the Admin Panel's value** |
| `PAYMENT_WEBHOOK_SECRET` | **yes** | Only if you connect a provider that posts signed webhooks |
| `PAYMENTS_MODE`, `PAYMENTS_LIVE_ENABLED`, `PAYMENT_PROVIDER` | no | Keep `test`/`false`/`mock`; manual payments do not need them |
| `NEXT_PUBLIC_APP_URL` | no | Site URL |
| `INITIAL_ADMIN_EMAIL`, `PROTECTED_AREA_SECRET`, `SCREENING_*`, `EMAIL_*` | — | Not needed by this app today (admin/screening/email live elsewhere or are not built) |

## How the shared Firebase / API connection works
- Both projects run the **same backend library** (`src/lib`) with the **same service account** against the **same Firestore + Storage**. The browser never touches Firestore/Storage directly (rules deny everything except `publicSettings` read); every read/write goes through server API routes with the Admin SDK.
- The Admin Panel is **not** a client of this app's HTTP API: it has its own `/api/admin/*` routes that read/write the same database. So there is no cross-origin traffic and no CORS config.
- Collections written here and read by the Admin Panel: `applications`, `payments`, `paymentRefs`, `rateLimits`, `contactMessages`, `notifications`, `auditLogs`. Collections written by the Admin Panel and read here: `paymentMethods`, `promoCodes`, `settings`, `publicSettings`, payment status fields.

## Works / does not work (verified = only by reading code, nothing was executed)
- Implemented in code: everything in the table above, server-side price computation, duplicate-payment protection, upload sniffing (PNG/JPEG/WebP, 4 MB), rate limits.
- **Not built:** automatic provider payment confirmation (the webhook receiver exists, but no real Stripe/PayPal adapter), email sending (verification emails use Firebase Auth's own mailer; no other email), password-reset page, applicant dashboard beyond the list in `/apply`, About/Services/FAQ pages, real screening provider.
- Security rules are **untested** unless you run `npm run test:rules` with the Firebase emulator.
