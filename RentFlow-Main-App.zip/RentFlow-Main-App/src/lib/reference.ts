import { randomBytes } from "node:crypto";

// No 0/O/1/I/L so references are easy to read aloud. 32^8 ≈ 1.1e12 combinations.
const ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

export function generateReference(): string {
  const bytes = randomBytes(8);
  let out = "";
  for (const b of bytes) out += ALPHABET[b % ALPHABET.length];
  return `RF-${out}`;
}
