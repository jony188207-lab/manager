// Append-only audit trail. Timestamps are SERVER timestamps. Firestore rules deny all client writes,
// and there is intentionally no update/delete helper anywhere in the codebase.
import { FieldValue } from "firebase-admin/firestore";
import { adminDb } from "@/lib/firebase/admin";

export type AuditMeta = Record<string, string | number | boolean | null>;

export interface AuditEntry {
  actorUid: string;
  actorEmail?: string;
  action: string; // e.g. "application.status_changed"
  targetType?: string;
  targetId?: string;
  meta?: AuditMeta;
  ip?: string;
}

const FORBIDDEN_KEY = /ssn|password|passcode|token|secret|card|cvv|cvc|pan|key|payload|report/i;

/** Keep audit metadata primitive and free of anything that looks sensitive. */
export function sanitizeMeta(meta: Record<string, unknown> | undefined): AuditMeta {
  const out: AuditMeta = {};
  for (const [k, v] of Object.entries(meta ?? {})) {
    if (FORBIDDEN_KEY.test(k)) continue;
    if (v === null || typeof v === "boolean" || typeof v === "number") out[k] = v;
    else if (typeof v === "string") out[k] = v.slice(0, 300);
  }
  return out;
}

export function clientIp(req: Request): string | undefined {
  return req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || undefined;
}

export async function writeAudit(e: AuditEntry): Promise<void> {
  await adminDb()
    .collection("auditLogs")
    .add({
      at: FieldValue.serverTimestamp(),
      actorUid: e.actorUid,
      actorEmail: e.actorEmail ?? null,
      action: e.action,
      targetType: e.targetType ?? null,
      targetId: e.targetId ?? null,
      meta: sanitizeMeta(e.meta),
      ip: e.ip ?? null,
    });
}
