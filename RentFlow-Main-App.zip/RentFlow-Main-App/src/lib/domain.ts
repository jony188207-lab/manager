// Shared domain constants and pure helpers (no I/O): statuses, mappings, CSV export safety.

export const APPLICATION_STATUSES = ["new", "pending", "approved", "rejected", "withdrawn"] as const;
export type ApplicationStatus = (typeof APPLICATION_STATUSES)[number];

/** Coarse status an applicant may see on the public status page. */
export function publicStatusFor(status: ApplicationStatus): string {
  switch (status) {
    case "new": return "received";
    case "pending": return "in_review";
    case "approved":
    case "rejected": return "decision_made";
    case "withdrawn": return "withdrawn";
  }
}

export const PAYMENT_STATUSES = [
  "pending", "pending_verification", "verified", "succeeded", "failed", "rejected",
  "refund_pending", "refunded", "partially_refunded",
] as const;
export type PaymentStatus = (typeof PAYMENT_STATUSES)[number];

export const SCREENING_STATUSES = [
  "queued", "running", "action_required", "provider_processing", "completed", "failed", "manual_review",
] as const;
export type ScreeningStatus = (typeof SCREENING_STATUSES)[number];

export const MAX_SCREENING_ATTEMPTS = 3;

/** Jobs may be retried only from these states, and only below the attempt cap. */
export function canRetryScreening(status: ScreeningStatus, attempts: number): boolean {
  return (status === "failed" || status === "action_required") && attempts < MAX_SCREENING_ATTEMPTS;
}

/** Neutralize spreadsheet formula injection and quote CSV fields. */
export function csvCell(value: unknown): string {
  let s = value == null ? "" : String(value);
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return `"${s.replace(/"/g, '""')}"`;
}

export function toCsv(rows: Record<string, unknown>[], columns: string[]): string {
  const lines = [columns.map(csvCell).join(",")];
  for (const r of rows) lines.push(columns.map((c) => csvCell(r[c])).join(","));
  return lines.join("\r\n");
}

/** Statuses that count as a confirmed payment (provider-verified OR admin-verified). */
export const PAID_STATUSES = ["succeeded", "verified"] as const;

/** Label shown to the applicant. A screenshot alone is never "Verified". */
export function applicantPaymentLabel(status: string, linkedToApplication: boolean): string {
  switch (status) {
    case "pending_verification": return linkedToApplication ? "Pending Verification" : "Submitted";
    case "verified":
    case "succeeded": return "Verified";
    case "rejected":
    case "failed": return "Rejected";
    case "refund_pending": return "Refund Pending";
    case "refunded":
    case "partially_refunded": return "Refunded";
    default: return "Pending Verification";
  }
}
