// Authenticated payment-webhook verification (HMAC-SHA256 over `${timestamp}.${rawBody}`).
// Header format: "t=<unix seconds>,v1=<hex signature>". Pure + unit-tested.
import { createHmac, timingSafeEqual } from "node:crypto";
import { z } from "zod";

export const WEBHOOK_TOLERANCE_SECONDS = 300;

export function computeSignature(rawBody: string, timestamp: number, secret: string): string {
  return createHmac("sha256", secret).update(`${timestamp}.${rawBody}`).digest("hex");
}

export function verifyWebhookSignature(
  rawBody: string,
  header: string | null,
  secret: string,
  nowSeconds = Math.floor(Date.now() / 1000),
  tolerance = WEBHOOK_TOLERANCE_SECONDS,
): boolean {
  if (!header || !secret) return false;
  const parts = Object.fromEntries(header.split(",").map((p) => p.trim().split("=") as [string, string]));
  const t = Number(parts.t);
  const sig = parts.v1;
  if (!Number.isFinite(t) || !sig) return false;
  if (Math.abs(nowSeconds - t) > tolerance) return false; // replay protection
  const expected = computeSignature(rawBody, t, secret);
  const a = Buffer.from(sig, "hex");
  const b = Buffer.from(expected, "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}

export const WebhookEvent = z.object({
  id: z.string().min(1).max(100),
  type: z.enum(["payment.succeeded", "payment.failed", "payment.refunded"]),
  data: z.object({
    providerRef: z.string().min(1).max(100),
    amountCents: z.number().int().nonnegative(),
    currency: z.string().length(3).default("usd"),
    cardBrand: z.string().max(30).optional(),
    cardLast4: z.string().regex(/^\d{4}$/).optional(),
  }),
});
export type WebhookEvent = z.infer<typeof WebhookEvent>;

/** Decide the next payment status from a verified event and the stored expected amount. */
export function applyEvent(
  event: WebhookEvent,
  expectedAmountCents: number,
): { status: "succeeded" | "failed" | "refunded" | "pending"; amountMismatch: boolean } {
  if (event.type === "payment.succeeded") {
    // Never mark paid if the provider-reported amount differs from what we charged.
    return event.data.amountCents === expectedAmountCents
      ? { status: "succeeded", amountMismatch: false }
      : { status: "pending", amountMismatch: true };
  }
  if (event.type === "payment.failed") return { status: "failed", amountMismatch: false };
  return { status: "refunded", amountMismatch: false };
}
