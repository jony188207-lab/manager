import { Timestamp } from "firebase-admin/firestore";

/** Recursively convert Firestore Timestamps to ISO strings so data is JSON-safe. */
export function serialize<T>(value: T): T {
  if (value instanceof Timestamp) return value.toDate().toISOString() as unknown as T;
  if (Array.isArray(value)) return value.map(serialize) as unknown as T;
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value as object).map(([k, v]) => [k, serialize(v)])) as T;
  }
  return value;
}
