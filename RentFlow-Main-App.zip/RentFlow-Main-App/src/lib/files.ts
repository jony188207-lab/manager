// Upload validation. We trust neither the filename nor the client-supplied MIME type: the file's
// leading bytes ("magic numbers") decide the type. Vercel serverless request bodies are limited to
// about 4.5 MB, so the cap stays safely below that.
import { HttpError } from "@/lib/http";

export const MAX_IMAGE_BYTES = 4 * 1024 * 1024;

export type SniffedImage = { mime: "image/png" | "image/jpeg" | "image/webp"; ext: "png" | "jpg" | "webp" };

export function sniffImage(buf: Uint8Array): SniffedImage | null {
  if (buf.length >= 8 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47 && buf[4] === 0x0d && buf[5] === 0x0a && buf[6] === 0x1a && buf[7] === 0x0a)
    return { mime: "image/png", ext: "png" };
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { mime: "image/jpeg", ext: "jpg" };
  if (buf.length >= 12 && buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46 && buf[8] === 0x57 && buf[9] === 0x45 && buf[10] === 0x42 && buf[11] === 0x50)
    return { mime: "image/webp", ext: "webp" };
  return null;
}

export interface ValidatedImage extends SniffedImage { buf: Buffer }

/** Reads an uploaded form file and validates size and real content type. Returns null if absent. */
export async function readImageUpload(entry: FormDataEntryValue | null): Promise<ValidatedImage | null> {
  if (entry === null || typeof entry === "string") return null;
  if (entry.size === 0) return null;
  if (entry.size > MAX_IMAGE_BYTES) throw new HttpError(413, "Image is too large (maximum 4 MB)");
  const buf = Buffer.from(await entry.arrayBuffer());
  if (buf.length > MAX_IMAGE_BYTES) throw new HttpError(413, "Image is too large (maximum 4 MB)");
  const kind = sniffImage(buf);
  if (!kind) throw new HttpError(400, "Only PNG, JPEG or WebP images are allowed");
  return { ...kind, buf };
}
