"use client";
import { getApp, getApps, initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

// These NEXT_PUBLIC values identify your Firebase project; they are not secrets.
// Access control is enforced by Firestore rules and server-side checks.
const config = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

export function firebaseApp() {
  return getApps().length ? getApp() : initializeApp(config);
}

export function firebaseAuth() {
  return getAuth(firebaseApp());
}
