// Server-side checkout helpers shared by the public checkout endpoint and payment creation.
import { adminDb } from "@/lib/firebase/admin";
import type { AppSettings } from "@/lib/config";
import { computeQuote, evaluatePromo, normalizePromoCode, type Promo } from "@/lib/pricing";
import type { StoredMethod } from "@/lib/paymentMethods";

export async function loadMethod(id: string): Promise<StoredMethod | null> {
  const snap = await adminDb().collection("paymentMethods").doc(id).get();
  return snap.exists ? ({ id: snap.id, ...snap.data() } as StoredMethod) : null;
}

export async function loadEnabledMethods(): Promise<StoredMethod[]> {
  const snap = await adminDb().collection("paymentMethods").where("enabled", "==", true).get();
  return snap.docs
    .map((d) => ({ id: d.id, ...d.data() }) as StoredMethod)
    .sort((a, b) => a.displayOrder - b.displayOrder || a.displayName.localeCompare(b.displayName));
}

export async function loadPromo(raw: string | undefined | null): Promise<Promo | null> {
  if (!raw) return null;
  const code = normalizePromoCode(raw);
  if (!/^[A-Z0-9_-]{3,32}$/.test(code)) return null;
  const snap = await adminDb().collection("promoCodes").doc(code).get();
  return snap.exists ? ({ code, usedCount: 0, ...snap.data() } as Promo) : null;
}

export type MethodQuote =
  | { ok: true; amountCents: number; currency: string; baseCents: number; discountCents: number; promoCode: string | null }
  | { ok: false; reason: string };

/** The ONLY place an expected payment amount is decided. */
export function quoteForMethod(m: StoredMethod, s: AppSettings, promo: Promo | null, nowMs: number): MethodQuote {
  const baseCents = m.amountMode === "fixed" ? (m.fixedAmountCents ?? s.totalFeeCents) : s.totalFeeCents;
  const currency = m.amountMode === "fixed" ? m.currency : s.baseCurrency;
  let applied: Promo | null = null;
  if (promo) {
    const check = evaluatePromo(promo, nowMs, currency, s.baseCurrency);
    if (!check.ok) return { ok: false, reason: check.reason };
    applied = promo;
  }
  const q = computeQuote(baseCents, applied);
  if (q.totalCents <= 0) return { ok: false, reason: "This promo code would reduce the fee to zero, which is not supported" };
  return { ok: true, amountCents: q.totalCents, currency, baseCents: q.baseCents, discountCents: q.discountCents, promoCode: applied?.code ?? null };
}
