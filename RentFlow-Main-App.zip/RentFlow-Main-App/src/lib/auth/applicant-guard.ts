// Applicant (non-admin) authentication for /api/applicant/*. Requires a verified email so the
// address used for status lookups and notices actually belongs to the applicant.
import { adminAuth } from "@/lib/firebase/admin";
import { HttpError } from "@/lib/http";
import { clientIp } from "@/lib/audit";

export interface ApplicantContext { uid: string; email: string; ip?: string }

export async function requireApplicant(req: Request): Promise<ApplicantContext> {
  const h = req.headers.get("authorization");
  if (!h?.startsWith("Bearer ")) throw new HttpError(401, "Please sign in");
  let decoded;
  try {
    decoded = await adminAuth().verifyIdToken(h.slice(7), true);
  } catch {
    throw new HttpError(401, "Your session expired. Please sign in again");
  }
  if (!decoded.email || decoded.email_verified !== true) throw new HttpError(403, "Please verify your email address first");
  return { uid: decoded.uid, email: decoded.email, ip: clientIp(req) };
}
