// Protected-area unlock logic: signed short-lived tokens + attempt throttling.
// Pure functions (no I/O) so they are unit-testable.
import { createHmac, timingSafeEqual } from "node:crypto";

export interface LockoutConfig {
  maxFailedAttempts: number; // configurable from Admin > Settings > Security
  lockoutMs: number;
}

export const DEFAULT_LOCKOUT: LockoutConfig = { maxFailedAttempts: 3, lockoutMs: 15 * 60 * 1000 };
// Back-compat exports used by existing tests/code.
export const MAX_PASSWORD_ATTEMPTS = DEFAULT_LOCKOUT.maxFailedAttempts;
export const LOCKOUT_MS = DEFAULT_LOCKOUT.lockoutMs;
export const UNLOCK_TTL_MS = 10 * 60 * 1000;

export interface AttemptState {
  failures: number;
  lockedUntil?: number; // epoch ms
}

export type AttemptDecision =
  | { allowed: true; requireTotp: boolean }
  | { allowed: false; retryAfterMs: number };

/** Before checking a password: is this admin currently locked out? */
export function checkAttemptState(
  state: AttemptState | null,
  now: number,
  cfg: LockoutConfig = DEFAULT_LOCKOUT,
): AttemptDecision {
  if (state?.lockedUntil && state.lockedUntil > now) {
    return { allowed: false, retryAfterMs: state.lockedUntil - now };
  }
  // After the failure threshold, a TOTP code is required in addition to the password.
  return { allowed: true, requireTotp: (state?.failures ?? 0) >= cfg.maxFailedAttempts };
}

/** After a failed attempt: next state (locks out once the threshold is reached). */
export function recordFailure(
  state: AttemptState | null,
  now: number,
  cfg: LockoutConfig = DEFAULT_LOCKOUT,
): AttemptState {
  const failures = (state?.failures ?? 0) + 1;
  return failures >= cfg.maxFailedAttempts ? { failures, lockedUntil: now + cfg.lockoutMs } : { failures };
}

export const resetAttempts = (): AttemptState => ({ failures: 0 });

function sign(payload: string, secret: string): string {
  return createHmac("sha256", secret).update(payload).digest("base64url");
}

export function issueUnlockToken(uid: string, secret: string, now = Date.now()): string {
  const payload = `${uid}.${now + UNLOCK_TTL_MS}`;
  return `${payload}.${sign(payload, secret)}`;
}

export function verifyUnlockToken(token: string | null, uid: string, secret: string, now = Date.now()): boolean {
  if (!token) return false;
  const parts = token.split(".");
  if (parts.length !== 3) return false;
  const [tUid, exp, sig] = parts as [string, string, string];
  const expected = sign(`${tUid}.${exp}`, secret);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return false;
  return tUid === uid && Number(exp) > now;
}
