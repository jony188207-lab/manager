// Guard for the Protected Information area: needs (1) the explicit per-admin grant,
// (2) a valid, unexpired, signed unlock token obtained via password re-authentication.
import { requirePermission, HttpError, type AdminContext } from "./admin-guard";
import { verifyUnlockToken } from "./protected-area";
import { serverEnv } from "@/lib/env";
import { writeAudit } from "@/lib/audit";

export async function requireProtectedAccess(req: Request, action: string): Promise<AdminContext> {
  const ctx = await requirePermission(req, "protected.view");
  const token = req.headers.get("x-unlock-token");
  if (!verifyUnlockToken(token, ctx.uid, serverEnv.protectedAreaSecret)) {
    await writeAudit({ actorUid: ctx.uid, actorEmail: ctx.email, action: "protected.access_denied", meta: { attempted: action }, ip: ctx.ip });
    throw new HttpError(403, "Re-authentication required");
  }
  return ctx;
}
