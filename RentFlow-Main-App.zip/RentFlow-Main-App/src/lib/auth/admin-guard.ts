// Server-only: verifies the Firebase ID token and enforces admin authorization on EVERY admin request.
import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { adminAuth, adminDb } from "@/lib/firebase/admin";
import { serverEnv } from "@/lib/env";
import { HttpError } from "@/lib/http";
import { writeAudit, clientIp } from "@/lib/audit";
import { authorizeAdmin, hasRole, type AdminRecord, type AdminRole } from "./authorize";
import { can, type Permission } from "./permissions";

export { HttpError };

export interface AdminContext {
  uid: string;
  email: string;
  role: AdminRole;
  canViewProtected: boolean;
  ip?: string;
}

function bearer(req: Request): string | null {
  const h = req.headers.get("authorization");
  return h?.startsWith("Bearer ") ? h.slice(7) : null;
}

async function resolveAdmin(req: Request): Promise<AdminContext> {
  const token = bearer(req);
  if (!token) throw new HttpError(401, "Not authenticated");

  let decoded;
  try {
    // checkRevoked=true: logging out (which revokes refresh tokens) ends the session server-side.
    decoded = await adminAuth().verifyIdToken(token, true);
  } catch {
    throw new HttpError(401, "Invalid or expired token");
  }

  const db = adminDb();
  const ref = db.collection("admins").doc(decoded.uid);
  const snap = await ref.get();
  let record = snap.exists ? (snap.data() as AdminRecord) : null;
  const ip = clientIp(req);

  // Pre-authorized email invite (created by a super_admin): consumed on first verified sign-in.
  if (!record && decoded.email && decoded.email_verified === true) {
    const inviteRef = db.collection("adminInvites").doc(decoded.email.toLowerCase());
    const invite = await inviteRef.get();
    if (invite.exists && invite.data()?.active === true) {
      const d = invite.data()!;
      record = { role: d.role, active: true, canViewProtected: d.canViewProtected === true };
      await ref.set({ ...record, email: decoded.email, createdAt: FieldValue.serverTimestamp(), createdBy: d.createdBy ?? null });
      await inviteRef.delete();
      await writeAudit({ actorUid: decoded.uid, actorEmail: decoded.email, action: "admin.invite_consumed", ip });
    }
  }

  const result = authorizeAdmin(decoded, record, serverEnv.initialAdminEmail);
  if (!result.ok) {
    if (result.status === 403 && decoded.email) {
      await writeAudit({
        actorUid: decoded.uid,
        actorEmail: decoded.email,
        action: "security.admin_access_denied",
        meta: { reason: result.reason },
        ip,
      });
    }
    throw new HttpError(result.status, result.reason);
  }

  if (result.bootstrap) {
    record = { role: "super_admin", active: true, canViewProtected: true };
    await ref.set({
      ...record,
      email: decoded.email,
      createdAt: FieldValue.serverTimestamp(),
      createdBy: "bootstrap:INITIAL_ADMIN_EMAIL",
    });
    await writeAudit({ actorUid: decoded.uid, actorEmail: decoded.email, action: "admin.bootstrap", ip });
  }

  return { uid: decoded.uid, email: decoded.email!, role: result.role, canViewProtected: record?.canViewProtected === true, ip };
}

/** Require a minimum role (kept for simple endpoints). */
export async function requireAdmin(req: Request, minimum: AdminRole = "viewer"): Promise<AdminContext> {
  const ctx = await resolveAdmin(req);
  if (!hasRole(ctx.role, minimum)) throw new HttpError(403, "Insufficient role");
  return ctx;
}

/** Require a specific permission. Preferred for all data endpoints. */
export async function requirePermission(req: Request, permission: Permission): Promise<AdminContext> {
  const ctx = await resolveAdmin(req);
  if (!can(ctx, permission)) {
    await writeAudit({
      actorUid: ctx.uid,
      actorEmail: ctx.email,
      action: "security.permission_denied",
      meta: { permission },
      ip: ctx.ip,
    });
    throw new HttpError(403, "Insufficient permission");
  }
  return ctx;
}

export function errorResponse(e: unknown) {
  if (e instanceof HttpError) return NextResponse.json({ error: e.message }, { status: e.status });
  console.error("Unhandled API error"); // never log request bodies, tokens, or applicant data
  return NextResponse.json({ error: "Internal error" }, { status: 500 });
}
