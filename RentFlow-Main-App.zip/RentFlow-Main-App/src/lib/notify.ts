// Admin in-app notifications. Messages must NEVER contain applicant PII or report contents.
import { FieldValue } from "firebase-admin/firestore";
import { adminDb } from "@/lib/firebase/admin";

export type NotificationType =
  | "application.new"
  | "payment.proof_submitted"
  | "payment.completed"
  | "payment.failed"
  | "screening.completed"
  | "screening.manual_review"
  | "system.error";

export async function createNotification(n: {
  type: NotificationType;
  title: string;
  /** Generic text only, e.g. "Application APP-1042 received". IDs are fine; names/emails are not. */
  message: string;
  link?: string;
  isSample?: boolean;
}): Promise<void> {
  await adminDb()
    .collection("notifications")
    .add({
      type: n.type,
      title: n.title,
      message: n.message,
      link: n.link ?? null,
      read: false,
      isSample: n.isSample === true,
      createdAt: FieldValue.serverTimestamp(),
    });
}
