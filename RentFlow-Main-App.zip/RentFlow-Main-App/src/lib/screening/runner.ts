// Advances one screening job using the configured provider adapter.
// Invariant: a job becomes `completed` ONLY when the provider returns verified: true.
import { FieldValue } from "firebase-admin/firestore";
import { adminDb } from "@/lib/firebase/admin";
import { encryptField } from "@/lib/crypto";
import { createNotification } from "@/lib/notify";
import { getScreeningProvider } from "./provider";
import type { ScreeningStatus } from "@/lib/domain";

export async function advanceJob(jobId: string): Promise<ScreeningStatus> {
  const db = adminDb();
  const ref = db.collection("screeningJobs").doc(jobId);
  const job = (await ref.get()).data();
  if (!job) throw new Error("Job not found");
  const provider = getScreeningProvider();
  const patch = (status: ScreeningStatus, extra: Record<string, unknown> = {}) =>
    ref.update({ status, updatedAt: FieldValue.serverTimestamp(), ...extra });

  try {
    await patch("running", { provider: provider.name, attempts: FieldValue.increment(1) });
    const { providerRef } = job.providerRef ? { providerRef: job.providerRef as string } : await provider.submit({ applicationId: job.applicationId });
    await patch("provider_processing", { providerRef });
    const result = await provider.poll(providerRef);

    if (result.state === "processing") return "provider_processing";
    if (result.state === "action_required") {
      await patch("action_required", { error: { code: "action_required", message: result.reason } });
      return "action_required";
    }
    if (result.state === "failed") {
      await patch("failed", { error: { code: result.code, message: result.message } });
      await createNotification({ type: "system.error", title: "Screening job failed", message: `Job ${jobId} failed (${result.code}).`, link: "/admin/screening" });
      return "failed";
    }

    // Completed payload from provider: store encrypted in the protected reports collection.
    await db.collection("screeningReports").add({
      jobId,
      applicationId: job.applicationId,
      payloadEnc: encryptField(JSON.stringify(result.payload)),
      verified: result.verified,
      isSample: job.isSample === true,
      createdAt: FieldValue.serverTimestamp(),
    });
    if (result.verified) {
      await patch("completed", { error: null });
      await createNotification({ type: "screening.completed", title: "Screening completed", message: `Job ${jobId} completed.`, link: "/admin/screening" });
      return "completed";
    }
    // Unverified results (e.g. the demo provider) are NEVER marked completed.
    await patch("manual_review", {
      manualReview: { status: "pending", note: "Provider result is not verified; human review required." },
    });
    await createNotification({ type: "screening.manual_review", title: "Manual review required", message: `Job ${jobId} needs manual review.`, link: "/admin/screening" });
    return "manual_review";
  } catch (e) {
    const message = e instanceof Error ? e.message.slice(0, 200) : "Unknown error";
    await patch("failed", { error: { code: "runner_error", message } });
    return "failed";
  }
}
