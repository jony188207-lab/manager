// INTEGRATION POINT for a future Playwright browser bot. Not implemented.
//
// Rules for any implementation:
//  - Use only where the screening provider explicitly authorizes automation in writing.
//  - Never solve/bypass CAPTCHAs or evade access controls; surface them as `action_required`.
//  - Run in a separate worker (not in Vercel serverless functions), reporting status through
//    the same screeningJobs documents and the protected report pipeline.
//  - Never log credentials, applicant data or report contents.
export interface ScreeningBot {
  readonly name: string;
  /** Returns a provider reference, or throws with a code the job runner records as error details. */
  run(job: { jobId: string; applicationId: string }): Promise<{ providerRef: string }>;
}
