import { LegalNotice } from "@/components/LegalNotice";

export const metadata = { title: "Applicant Rights" };

const rights = [
  "Receive a clear disclosure, in a standalone document, that a consumer report may be obtained, and give or withhold written authorization.",
  "Be told if an adverse decision is based in whole or part on a consumer report, including the name and contact details of the reporting agency.",
  "Receive a copy of your report and a summary of your rights from the reporting agency.",
  "Dispute inaccurate or incomplete information directly with the reporting agency and with us.",
  "Request access to, correction of, or deletion of your information where state law provides.",
  "Additional protections that may apply under state and local rental-screening laws in your area.",
];

export default function ApplicantRights() {
  return (
    <article className="max-w-3xl space-y-4 text-sm text-slate-700">
      <LegalNotice />
      <h1 className="text-2xl font-bold text-slate-900">Applicant Rights</h1>
      <p>This summary is informational and is not legal advice. Rights vary by location.</p>
      <ul className="list-disc space-y-2 pl-5">
        {rights.map((r) => <li key={r}>{r}</li>)}
      </ul>
      <p>To raise a concern or dispute, <a className="text-brand-600 underline" href="/contact">contact us</a>.</p>
    </article>
  );
}
