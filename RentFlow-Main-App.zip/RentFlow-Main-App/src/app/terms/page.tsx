import { LegalNotice } from "@/components/LegalNotice";

export const metadata = { title: "Terms and Conditions" };

export default function Terms() {
  return (
    <article className="max-w-3xl space-y-4 text-sm leading-relaxed text-slate-700">
      <LegalNotice />
      <h1 className="text-2xl font-bold text-slate-900">Terms and Conditions</h1>
      <h2 className="text-lg font-semibold text-slate-900">Use of the service</h2>
      <p>RentFlow helps collect rental applications and request tenant screening reports. Submitting an application does not guarantee approval or tenancy.</p>
      <h2 className="text-lg font-semibold text-slate-900">Accuracy</h2>
      <p>You agree that the information you provide is accurate and complete. Material misstatements may affect your application.</p>
      <h2 className="text-lg font-semibold text-slate-900">Fees</h2>
      <p>The application fee shown at checkout is charged once. Refund terms: [Operator: insert policy and confirm applicable state limits on application fees.]</p>
      <h2 className="text-lg font-semibold text-slate-900">Screening</h2>
      <p>Screening reports are prepared by an authorized consumer reporting agency. Decisions are made by the housing provider after human review, not automatically by this system.</p>
      <h2 className="text-lg font-semibold text-slate-900">Disputes</h2>
      <p>Disputes about report accuracy should be directed to the reporting agency identified in any notice you receive.</p>
    </article>
  );
}
