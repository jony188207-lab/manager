import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse } from "@/lib/auth/admin-guard";
import { requireApplicant } from "@/lib/auth/applicant-guard";
import { writeAudit } from "@/lib/audit";
import { getAppSettings } from "@/lib/config";
import { ApplicationInput } from "@/lib/applicationSchema";
import { encryptField } from "@/lib/crypto";
import { applicantPaymentLabel } from "@/lib/domain";
import { HttpError, parseInput, readJson } from "@/lib/http";
import { createNotification } from "@/lib/notify";
import { rateLimit } from "@/lib/ratelimit";
import { generateReference } from "@/lib/reference";
import { serialize } from "@/lib/serialize";

export const dynamic = "force-dynamic";

// The applicant's own applications and their payment progress. Nothing else is readable here.
export async function GET(req: Request) {
  try {
    const a = await requireApplicant(req);
    const db = adminDb();
    const [apps, pays] = await Promise.all([
      db.collection("applications").where("applicantUid", "==", a.uid).limit(20).get(),
      db.collection("payments").where("applicantUid", "==", a.uid).limit(50).get(),
    ]);
    const payById = new Map(pays.docs.map((d) => [d.id, d.data()]));
    const applications = apps.docs
      .map((d) => {
        const x = d.data();
        const p = payById.get(x.paymentId);
        return serialize({
          reference: d.id,
          applicationStatus: x.publicStatus ?? "received",
          createdAt: x.createdAt,
          payment: p ? { label: applicantPaymentLabel(p.status, true), amountCents: p.amountCents, currency: p.currency } : null,
        });
      })
      .sort((x, y) => String(y.createdAt).localeCompare(String(x.createdAt)));
    // Proofs submitted but not yet attached to an application (applicant can continue with these).
    const unlinkedPayments = pays.docs
      .filter((d) => !d.data().applicationId && ["pending_verification", "verified"].includes(d.data().status))
      .map((d) => serialize({ paymentId: d.id, label: applicantPaymentLabel(d.data().status, false), amountCents: d.data().amountCents, currency: d.data().currency, methodName: d.data().methodName }));
    return NextResponse.json({ applications, unlinkedPayments }, { headers: { "Cache-Control": "no-store" } });
  } catch (e) {
    return errorResponse(e);
  }
}

// Submit the application. Allowed only after payment proof exists for THIS applicant, once.
export async function POST(req: Request) {
  try {
    const a = await requireApplicant(req);
    await rateLimit("application-submit", a.uid, 5, 3600);
    const input = parseInput(ApplicationInput, await readJson(req));
    const settings = await getAppSettings();
    if (!settings.applicationsEnabled) throw new HttpError(403, "New applications are currently closed");

    const db = adminDb();
    const payRef = db.collection("payments").doc(input.paymentId);
    let reference = "";

    for (let attempt = 0; attempt < 4 && !reference; attempt++) {
      const candidate = generateReference();
      const appRef = db.collection("applications").doc(candidate);
      const ok = await db.runTransaction(async (tx) => {
        const [pay, clash] = await Promise.all([tx.get(payRef), tx.get(appRef)]);
        if (clash.exists) return false; // extremely unlikely reference collision: try another
        const p = pay.data();
        // Payment proof must exist, belong to this applicant, be unused, and not be rejected/refunded.
        if (!pay.exists || p?.applicantUid !== a.uid) throw new HttpError(403, "Submit your payment proof first");
        if (p.applicationId) throw new HttpError(409, "This payment has already been used for an application");
        if (!["pending_verification", "verified", "succeeded"].includes(p.status)) throw new HttpError(409, "This payment can no longer be used. Please submit a new payment");
        tx.create(appRef, {
          applicantUid: a.uid,
          applicantName: input.fullName,
          applicantNameLower: input.fullName.toLowerCase(),
          applicantEmail: a.email,
          applicantEmailLower: a.email.toLowerCase(),
          applicantPhone: input.phone,
          property: input.property,
          household: input.household,
          employment: input.employment,
          rentalHistory: input.rentalHistory,
          ssnEnc: input.ssn ? encryptField(input.ssn.replace(/-/g, "")) : null,
          consent: {
            fcraDisclosureAcceptedAt: FieldValue.serverTimestamp(),
            authorizationAcceptedAt: FieldValue.serverTimestamp(),
            version: settings.consentVersion,
            ip: a.ip ?? null,
          },
          paymentId: input.paymentId,
          status: "new",
          publicStatus: "received",
          isSample: false,
          createdAt: FieldValue.serverTimestamp(),
          updatedAt: FieldValue.serverTimestamp(),
        });
        tx.update(payRef, { applicationId: candidate, updatedAt: FieldValue.serverTimestamp() });
        return true;
      });
      if (ok) reference = candidate;
    }
    if (!reference) throw new HttpError(500, "Could not create the application. Please try again");

    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "application.submitted", targetType: "application", targetId: reference, ip: a.ip });
    await createNotification({ type: "application.new", title: "New application received", message: `Application ${reference} received.`, link: "/admin/applications" });
    return NextResponse.json({ reference, status: "received" }, { status: 201 });
  } catch (e) {
    return errorResponse(e);
  }
}
