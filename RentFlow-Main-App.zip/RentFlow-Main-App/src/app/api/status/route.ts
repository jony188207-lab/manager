import { NextResponse } from "next/server";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { applicantPaymentLabel } from "@/lib/domain";
import { clientIp } from "@/lib/audit";
import { rateLimit } from "@/lib/ratelimit";

export const dynamic = "force-dynamic";

const Body = z.object({ applicationId: z.string().trim().min(6).max(64), email: z.string().email().max(200) });

// Public lookup. Requires BOTH the reference number and the email on file; returns only coarse
// statuses. The same message is returned for "not found" and "email mismatch". Rate limited per IP.
export async function POST(req: Request) {
  const notFound = NextResponse.json({ error: "No matching application found." }, { status: 404 });
  try {
    await rateLimit("status-lookup", clientIp(req), 20, 600);
  } catch {
    return NextResponse.json({ error: "Too many requests. Please try again later." }, { status: 429 });
  }
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return notFound;
  try {
    const db = adminDb();
    const snap = await db.collection("applications").doc(parsed.data.applicationId.toUpperCase()).get();
    const data = snap.data();
    if (!snap.exists || data?.applicantEmail?.toLowerCase() !== parsed.data.email.toLowerCase()) return notFound;
    const pay = data.paymentId ? (await db.collection("payments").doc(data.paymentId).get()).data() : undefined;
    return NextResponse.json({
      status: data.publicStatus ?? "received",
      paymentStatus: pay ? applicantPaymentLabel(pay.status, true) : null,
    });
  } catch {
    return NextResponse.json({ error: "Service unavailable." }, { status: 503 });
  }
}
