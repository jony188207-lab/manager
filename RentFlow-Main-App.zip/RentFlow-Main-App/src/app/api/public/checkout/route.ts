import { NextResponse } from "next/server";
import { z } from "zod";
import { errorResponse } from "@/lib/auth/admin-guard";
import { clientIp } from "@/lib/audit";
import { getAppSettings } from "@/lib/config";
import { loadEnabledMethods, loadPromo, quoteForMethod } from "@/lib/checkout";
import { methodAvailableIn } from "@/lib/paymentMethods";
import { parseInput, queryParams } from "@/lib/http";
import { rateLimit } from "@/lib/ratelimit";

export const dynamic = "force-dynamic";

const Params = z.object({
  country: z.string().regex(/^[A-Za-z]{2}$/).optional(),
  promo: z.string().max(40).optional(),
});

// Public: what the applicant sees at checkout. Amounts are computed here on the server from admin
// settings. Only fields meant for applicants are returned (no internal ids beyond the method id).
export async function GET(req: Request) {
  try {
    await rateLimit("checkout", clientIp(req), 60, 60);
    const p = parseInput(Params, queryParams(req));
    const country = p.country?.toUpperCase();
    const [settings, methods, promo] = await Promise.all([getAppSettings(), loadEnabledMethods(), loadPromo(p.promo)]);
    const now = Date.now();

    let promoStatus: { code: string; valid: boolean; reason?: string } | null = null;
    const items = methods
      .filter((m) => methodAvailableIn(m, country))
      .map((m) => {
        const q = quoteForMethod(m, settings, promo, now);
        if (p.promo && !promoStatus) promoStatus = { code: p.promo.trim().toUpperCase(), valid: Boolean(promo) && q.ok, reason: !promo ? "This promo code is not valid" : q.ok ? undefined : q.reason };
        // If the promo fails for this method, show the undiscounted price for it.
        const price = q.ok ? q : quoteForMethod(m, settings, null, now);
        return {
          id: m.id,
          provider: m.provider,
          displayName: m.displayName,
          description: m.description,
          instructions: m.instructions,
          applicantGuidance: m.applicantGuidance,
          paymentUrl: m.paymentUrl ?? null,
          identifier: m.identifier ?? null,
          hasQr: m.hasQr === true,
          amountCents: price.ok ? price.amountCents : null,
          currency: price.ok ? price.currency : m.currency,
          discountCents: price.ok ? price.discountCents : 0,
        };
      });

    return NextResponse.json({
      applicationsEnabled: settings.applicationsEnabled,
      requireScreenshot: settings.requireScreenshot,
      baseCurrency: settings.baseCurrency,
      baseCents: settings.totalFeeCents,
      promo: promoStatus ?? (p.promo ? { code: p.promo.trim().toUpperCase(), valid: false, reason: "This promo code is not valid" } : null),
      methods: items,
    });
  } catch (e) {
    return errorResponse(e);
  }
}
