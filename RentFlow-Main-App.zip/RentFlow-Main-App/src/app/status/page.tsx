"use client";
import { useState } from "react";

export default function StatusPage() {
  const [result, setResult] = useState<{ status?: string; paymentStatus?: string | null; error?: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    const f = new FormData(e.currentTarget);
    const res = await fetch("/api/status", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ applicationId: f.get("applicationId"), email: f.get("email") }),
    });
    setResult(await res.json());
    setBusy(false);
  }

  return (
    <div className="max-w-xl">
      <h1 className="text-2xl font-bold">Application status</h1>
      <form onSubmit={onSubmit} className="card mt-6 space-y-4">
        <div>
          <label className="label" htmlFor="applicationId">Reference number (RF-XXXXXXXX)</label>
          <input id="applicationId" name="applicationId" required className="input" />
        </div>
        <div>
          <label className="label" htmlFor="email">Email used on application</label>
          <input id="email" name="email" type="email" required className="input" />
        </div>
        <button className="btn-primary" disabled={busy}>{busy ? "Checking…" : "Check status"}</button>
      </form>
      {result && (
        <div className="card mt-4" role="status">
          {result.status ? (
            <div className="space-y-1"><p>Application: <strong>{result.status.replace(/_/g, " ")}</strong></p>{result.paymentStatus && <p>Payment: <strong>{result.paymentStatus}</strong></p>}</div>
          ) : (
            <p className="text-sm text-slate-600">{result.error ?? "No matching application found."}</p>
          )}
        </div>
      )}
    </div>
  );
}
