import { describe, expect, it } from "vitest";
import { canRetryScreening, csvCell, publicStatusFor, toCsv } from "@/lib/domain";
import { sanitizeMeta } from "@/lib/audit";

describe("csv export safety", () => {
  it("neutralizes spreadsheet formula injection and escapes quotes", () => {
    expect(csvCell("=HYPERLINK(\"x\")")).toBe(`"'=HYPERLINK(""x"")"`);
    expect(csvCell("+1")).toBe(`"'+1"`);
    expect(csvCell("normal")).toBe(`"normal"`);
  });
  it("builds a CSV with header", () => {
    expect(toCsv([{ a: 1, b: "x" }], ["a", "b"])).toBe(`"a","b"\r\n"1","x"`);
  });
});

describe("status mapping", () => {
  it("never reveals approve/reject outcome on the public status", () => {
    expect(publicStatusFor("approved")).toBe("decision_made");
    expect(publicStatusFor("rejected")).toBe("decision_made");
  });
});

describe("screening retry rules", () => {
  it("retries only failed/action_required below the cap", () => {
    expect(canRetryScreening("failed", 1)).toBe(true);
    expect(canRetryScreening("failed", 3)).toBe(false);
    expect(canRetryScreening("completed", 0)).toBe(false);
    expect(canRetryScreening("running", 0)).toBe(false);
  });
});

describe("audit metadata sanitization", () => {
  it("drops sensitive-looking keys and non-primitive values", () => {
    const out = sanitizeMeta({ from: "new", ssn: "123", cardNumber: "4242", password: "x", unlockToken: "t", payload: "p", nested: { a: 1 }, count: 2 });
    expect(out).toEqual({ from: "new", count: 2 });
  });
});
