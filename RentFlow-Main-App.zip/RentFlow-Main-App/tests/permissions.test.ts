import { describe, expect, it } from "vitest";
import { can } from "@/lib/auth/permissions";

describe("role permissions", () => {
  it("viewer can read but not change anything", () => {
    expect(can({ role: "viewer" }, "applications.read")).toBe(true);
    expect(can({ role: "viewer" }, "applications.update")).toBe(false);
    expect(can({ role: "viewer" }, "payments.manage")).toBe(false);
    expect(can({ role: "viewer" }, "audit.read")).toBe(false);
  });
  it("reviewer can update and reject, but cannot export, change settings, or manage admins", () => {
    const s = { role: "reviewer" as const };
    expect(can(s, "applications.update")).toBe(true);
    expect(can(s, "applications.reject")).toBe(true);
    expect(can(s, "applications.export")).toBe(false);
    expect(can(s, "settings.write")).toBe(false);
    expect(can(s, "admins.manage")).toBe(false);
  });
  it("only super_admin manages admins", () => {
    expect(can({ role: "admin" }, "admins.manage")).toBe(false);
    expect(can({ role: "super_admin" }, "admins.manage")).toBe(true);
  });
  it("protected access needs the explicit grant: no role implies it, even super_admin", () => {
    expect(can({ role: "super_admin" }, "protected.view")).toBe(false);
    expect(can({ role: "admin" }, "protected.view")).toBe(false);
    expect(can({ role: "admin", canViewProtected: true }, "protected.view")).toBe(true);
  });
  it("a viewer cannot hold protected access even if the flag is set", () => {
    expect(can({ role: "viewer", canViewProtected: true }, "protected.view")).toBe(false);
  });
});
