import { describe, expect, it } from "vitest";
import {
  LOCKOUT_MS,
  checkAttemptState,
  issueUnlockToken,
  recordFailure,
  verifyUnlockToken,
} from "@/lib/auth/protected-area";

describe("protected-area attempts", () => {
  it("requires TOTP and locks out after three consecutive failures", () => {
    const now = 1_000_000;
    let s = recordFailure(null, now);
    s = recordFailure(s, now);
    expect(checkAttemptState(s, now)).toEqual({ allowed: true, requireTotp: false });
    s = recordFailure(s, now);
    expect(s.lockedUntil).toBe(now + LOCKOUT_MS);
    expect(checkAttemptState(s, now + 1)).toMatchObject({ allowed: false });
    expect(checkAttemptState(s, now + LOCKOUT_MS + 1)).toEqual({ allowed: true, requireTotp: true });
  });
});

describe("unlock tokens", () => {
  const secret = "test-secret";
  it("accepts a fresh token for the same admin", () => {
    expect(verifyUnlockToken(issueUnlockToken("u1", secret, 0), "u1", secret, 1000)).toBe(true);
  });
  it("rejects expired, wrong-user, tampered, and missing tokens", () => {
    const t = issueUnlockToken("u1", secret, 0);
    expect(verifyUnlockToken(t, "u1", secret, 11 * 60 * 1000)).toBe(false);
    expect(verifyUnlockToken(t, "u2", secret, 1000)).toBe(false);
    expect(verifyUnlockToken(t + "x", "u1", secret, 1000)).toBe(false);
    expect(verifyUnlockToken(t, "u1", "other-secret", 1000)).toBe(false);
    expect(verifyUnlockToken(null, "u1", secret)).toBe(false);
  });
});
