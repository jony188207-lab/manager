import { describe, expect, it } from "vitest";
import { authorizeAdmin, hasRole } from "@/lib/auth/authorize";

const verified = { uid: "u1", email: "Boss@Gmail.com", email_verified: true };

describe("authorizeAdmin", () => {
  it("rejects unauthenticated requests with 401", () => {
    expect(authorizeAdmin(null, null, "boss@gmail.com")).toMatchObject({ ok: false, status: 401 });
  });
  it("rejects unverified email even if it matches the initial admin", () => {
    expect(authorizeAdmin({ ...verified, email_verified: false }, null, "boss@gmail.com")).toMatchObject({ ok: false, status: 403 });
  });
  it("bootstraps super_admin only for the configured verified email (case-insensitive)", () => {
    expect(authorizeAdmin(verified, null, "boss@gmail.com")).toEqual({ ok: true, role: "super_admin", bootstrap: true });
  });
  it("denies everyone when INITIAL_ADMIN_EMAIL is empty", () => {
    expect(authorizeAdmin(verified, null, "")).toMatchObject({ ok: false, status: 403 });
  });
  it("denies a non-admin verified user", () => {
    expect(authorizeAdmin({ ...verified, email: "x@gmail.com" }, null, "boss@gmail.com")).toMatchObject({ ok: false, status: 403 });
  });
  it("denies disabled admins and allows active ones with their role", () => {
    expect(authorizeAdmin(verified, { role: "admin", active: false }, "")).toMatchObject({ ok: false, status: 403 });
    expect(authorizeAdmin(verified, { role: "reviewer", active: true }, "")).toEqual({ ok: true, role: "reviewer", bootstrap: false });
  });
});

describe("hasRole", () => {
  it("orders roles", () => {
    expect(hasRole("admin", "reviewer")).toBe(true);
    expect(hasRole("viewer", "reviewer")).toBe(false);
  });
});
